﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string auxiliar = txtPalavra1.Text;
            char[] arr = auxiliar.ToCharArray();
            Array.Reverse(arr); //Invertendo array

            //auxiliar = new string(arr); //Se usar esse, não precisa no de baixo
            auxiliar = "";
            foreach (char cara in arr)
            {
                auxiliar += cara.ToString();
            }
            
            txtPalavra1.Text = auxiliar;
        }

        private void btnRemoverOcorrencias1no2_Click(object sender, EventArgs e)
        {
            txtPalavra2.Text = txtPalavra2.Text.Replace(txtPalavra1.Text, "");
        }
    }
}

﻿namespace Ptriangulo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            lblValor1 = new Label();
            lblValor2 = new Label();
            lblValor3 = new Label();
            txtValor1 = new TextBox();
            txtValor2 = new TextBox();
            txtValor3 = new TextBox();
            btnCalcular = new Button();
            btnLimpar = new Button();
            btnSair = new Button();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // lblValor1
            // 
            lblValor1.AutoSize = true;
            lblValor1.Location = new Point(18, 32);
            lblValor1.Margin = new Padding(2, 0, 2, 0);
            lblValor1.Name = "lblValor1";
            lblValor1.Size = new Size(42, 15);
            lblValor1.TabIndex = 0;
            lblValor1.Text = "Valor 1";
            // 
            // lblValor2
            // 
            lblValor2.AutoSize = true;
            lblValor2.Location = new Point(18, 63);
            lblValor2.Margin = new Padding(2, 0, 2, 0);
            lblValor2.Name = "lblValor2";
            lblValor2.Size = new Size(42, 15);
            lblValor2.TabIndex = 1;
            lblValor2.Text = "Valor 2";
            // 
            // lblValor3
            // 
            lblValor3.AutoSize = true;
            lblValor3.Location = new Point(18, 100);
            lblValor3.Margin = new Padding(2, 0, 2, 0);
            lblValor3.Name = "lblValor3";
            lblValor3.Size = new Size(42, 15);
            lblValor3.TabIndex = 2;
            lblValor3.Text = "Valor 3";
            // 
            // txtValor1
            // 
            txtValor1.Location = new Point(92, 29);
            txtValor1.Margin = new Padding(2);
            txtValor1.Name = "txtValor1";
            txtValor1.Size = new Size(106, 23);
            txtValor1.TabIndex = 3;
            txtValor1.Validated += txtValor1_Validated;
            // 
            // txtValor2
            // 
            txtValor2.Location = new Point(92, 63);
            txtValor2.Margin = new Padding(2);
            txtValor2.Name = "txtValor2";
            txtValor2.Size = new Size(106, 23);
            txtValor2.TabIndex = 4;
            txtValor2.Validated += txtValor2_Validated;
            // 
            // txtValor3
            // 
            txtValor3.Location = new Point(92, 97);
            txtValor3.Margin = new Padding(2);
            txtValor3.Name = "txtValor3";
            txtValor3.Size = new Size(106, 23);
            txtValor3.TabIndex = 5;
            txtValor3.Validated += txtValor3_Validated;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(14, 177);
            btnCalcular.Margin = new Padding(2);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(83, 31);
            btnCalcular.TabIndex = 6;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(127, 177);
            btnLimpar.Margin = new Padding(2);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(87, 31);
            btnLimpar.TabIndex = 7;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(242, 177);
            btnSair.Margin = new Padding(2);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(83, 31);
            btnSair.TabIndex = 8;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(242, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(321, 145);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 9;
            pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(589, 231);
            Controls.Add(pictureBox1);
            Controls.Add(btnSair);
            Controls.Add(btnLimpar);
            Controls.Add(btnCalcular);
            Controls.Add(txtValor3);
            Controls.Add(txtValor2);
            Controls.Add(txtValor1);
            Controls.Add(lblValor3);
            Controls.Add(lblValor2);
            Controls.Add(lblValor1);
            Margin = new Padding(2);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblValor1;
        private Label lblValor2;
        private Label lblValor3;
        private TextBox txtValor1;
        private TextBox txtValor2;
        private TextBox txtValor3;
        private Button btnCalcular;
        private Button btnLimpar;
        private Button btnSair;
        private PictureBox pictureBox1;
    }
}

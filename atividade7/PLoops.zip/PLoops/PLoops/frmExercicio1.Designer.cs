﻿namespace PLoops
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            rchtxtTexto = new RichTextBox();
            btnEspacoBranco = new Button();
            btnVezesR = new Button();
            btnParLetras = new Button();
            SuspendLayout();
            // 
            // rchtxtTexto
            // 
            rchtxtTexto.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            rchtxtTexto.Location = new Point(19, 70);
            rchtxtTexto.Margin = new Padding(2, 2, 2, 2);
            rchtxtTexto.MaxLength = 100;
            rchtxtTexto.Name = "rchtxtTexto";
            rchtxtTexto.Size = new Size(512, 41);
            rchtxtTexto.TabIndex = 0;
            rchtxtTexto.Text = "";
            // 
            // btnEspacoBranco
            // 
            btnEspacoBranco.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnEspacoBranco.Location = new Point(19, 149);
            btnEspacoBranco.Margin = new Padding(2, 2, 2, 2);
            btnEspacoBranco.Name = "btnEspacoBranco";
            btnEspacoBranco.Size = new Size(146, 73);
            btnEspacoBranco.TabIndex = 1;
            btnEspacoBranco.Text = "Número de espaços em branco na frase";
            btnEspacoBranco.UseVisualStyleBackColor = true;
            btnEspacoBranco.Click += btnEspacoBranco_Click;
            // 
            // btnVezesR
            // 
            btnVezesR.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnVezesR.Location = new Point(186, 149);
            btnVezesR.Margin = new Padding(2, 2, 2, 2);
            btnVezesR.Name = "btnVezesR";
            btnVezesR.Size = new Size(148, 73);
            btnVezesR.TabIndex = 2;
            btnVezesR.Text = "Número de vezes que aparece a letra \"R\"";
            btnVezesR.UseVisualStyleBackColor = true;
            btnVezesR.Click += btnVezesR_Click;
            // 
            // btnParLetras
            // 
            btnParLetras.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnParLetras.Location = new Point(357, 149);
            btnParLetras.Margin = new Padding(2, 2, 2, 2);
            btnParLetras.Name = "btnParLetras";
            btnParLetras.Size = new Size(174, 73);
            btnParLetras.TabIndex = 3;
            btnParLetras.Text = "Número de vezes que ocorre o mesmo par de letras";
            btnParLetras.UseVisualStyleBackColor = true;
            btnParLetras.Click += btnParLetras_Click;
            // 
            // frmExercicio1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(546, 251);
            Controls.Add(btnParLetras);
            Controls.Add(btnVezesR);
            Controls.Add(btnEspacoBranco);
            Controls.Add(rchtxtTexto);
            Margin = new Padding(2, 2, 2, 2);
            Name = "frmExercicio1";
            Text = "frmExercicio1";
            ResumeLayout(false);
        }

        #endregion

        private RichTextBox rchtxtTexto;
        private Button btnEspacoBranco;
        private Button btnVezesR;
        private Button btnParLetras;
    }
}
﻿namespace Pclasses
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblMatrícula = new Label();
            lblNome = new Label();
            lblSalárioMensal = new Label();
            lblDataEntradanaEmpresa = new Label();
            txtMatricula = new TextBox();
            txtNome = new TextBox();
            txtSalarioMensal = new TextBox();
            txtDataEntradaNaEmpresa = new TextBox();
            btnInstanciarMensalista = new Button();
            btnInstanciarMesalista = new Button();
            SuspendLayout();
            // 
            // lblMatrícula
            // 
            lblMatrícula.AutoSize = true;
            lblMatrícula.Location = new Point(100, 45);
            lblMatrícula.Name = "lblMatrícula";
            lblMatrícula.Size = new Size(84, 25);
            lblMatrícula.TabIndex = 0;
            lblMatrícula.Text = "Matrícula";
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Location = new Point(100, 101);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(61, 25);
            lblNome.TabIndex = 1;
            lblNome.Text = "Nome";
            // 
            // lblSalárioMensal
            // 
            lblSalárioMensal.AutoSize = true;
            lblSalárioMensal.Location = new Point(58, 167);
            lblSalárioMensal.Name = "lblSalárioMensal";
            lblSalárioMensal.Size = new Size(126, 25);
            lblSalárioMensal.TabIndex = 2;
            lblSalárioMensal.Text = "Salário Mensal";
            // 
            // lblDataEntradanaEmpresa
            // 
            lblDataEntradanaEmpresa.AutoSize = true;
            lblDataEntradanaEmpresa.Location = new Point(12, 226);
            lblDataEntradanaEmpresa.Name = "lblDataEntradanaEmpresa";
            lblDataEntradanaEmpresa.Size = new Size(240, 25);
            lblDataEntradanaEmpresa.TabIndex = 3;
            lblDataEntradanaEmpresa.Text = "Data da entrada na empresa:";
            // 
            // txtMatricula
            // 
            txtMatricula.Location = new Point(269, 45);
            txtMatricula.Name = "txtMatricula";
            txtMatricula.Size = new Size(150, 31);
            txtMatricula.TabIndex = 4;
            // 
            // txtNome
            // 
            txtNome.Location = new Point(269, 101);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(150, 31);
            txtNome.TabIndex = 5;
            // 
            // txtSalarioMensal
            // 
            txtSalarioMensal.Location = new Point(269, 161);
            txtSalarioMensal.Name = "txtSalarioMensal";
            txtSalarioMensal.Size = new Size(150, 31);
            txtSalarioMensal.TabIndex = 6;
            // 
            // txtDataEntradaNaEmpresa
            // 
            txtDataEntradaNaEmpresa.Location = new Point(269, 226);
            txtDataEntradaNaEmpresa.Name = "txtDataEntradaNaEmpresa";
            txtDataEntradaNaEmpresa.Size = new Size(150, 31);
            txtDataEntradaNaEmpresa.TabIndex = 7;
            // 
            // btnInstanciarMensalista
            // 
            btnInstanciarMensalista.Location = new Point(91, 301);
            btnInstanciarMensalista.Name = "btnInstanciarMensalista";
            btnInstanciarMensalista.Size = new Size(215, 91);
            btnInstanciarMensalista.TabIndex = 8;
            btnInstanciarMensalista.Text = "Instanciar Mensalista";
            btnInstanciarMensalista.UseVisualStyleBackColor = true;
            btnInstanciarMensalista.Click += btnInstanciarMensalista_Click;
            // 
            // btnInstanciarMesalista
            // 
            btnInstanciarMesalista.Location = new Point(370, 301);
            btnInstanciarMesalista.Name = "btnInstanciarMesalista";
            btnInstanciarMesalista.Size = new Size(244, 91);
            btnInstanciarMesalista.TabIndex = 9;
            btnInstanciarMesalista.Text = "Instanciar Mensalista passando parâmetros";
            btnInstanciarMesalista.UseVisualStyleBackColor = true;
            btnInstanciarMesalista.Click += btnInstanciarMesalista_Click;
            // 
            // frmMensalista
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnInstanciarMesalista);
            Controls.Add(btnInstanciarMensalista);
            Controls.Add(txtDataEntradaNaEmpresa);
            Controls.Add(txtSalarioMensal);
            Controls.Add(txtNome);
            Controls.Add(txtMatricula);
            Controls.Add(lblDataEntradanaEmpresa);
            Controls.Add(lblSalárioMensal);
            Controls.Add(lblNome);
            Controls.Add(lblMatrícula);
            Name = "frmMensalista";
            Text = "frmMensalista";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblMatrícula;
        private Label lblNome;
        private Label lblSalárioMensal;
        private Label lblDataEntradanaEmpresa;
        private TextBox txtMatricula;
        private TextBox txtNome;
        private TextBox txtSalarioMensal;
        private TextBox txtDataEntradaNaEmpresa;
        private Button btnInstanciarMensalista;
        private Button btnInstanciarMesalista;
    }
}
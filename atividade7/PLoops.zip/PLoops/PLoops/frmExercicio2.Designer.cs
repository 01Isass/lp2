﻿namespace PLoops
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtN = new TextBox();
            lblDigiteNumero = new Label();
            btnCalcula = new Button();
            lblNumeroH = new Label();
            txtH = new TextBox();
            SuspendLayout();
            // 
            // txtN
            // 
            txtN.Location = new Point(154, 46);
            txtN.Name = "txtN";
            txtN.Size = new Size(141, 23);
            txtN.TabIndex = 0;
            // 
            // lblDigiteNumero
            // 
            lblDigiteNumero.AutoSize = true;
            lblDigiteNumero.Location = new Point(28, 49);
            lblDigiteNumero.Name = "lblDigiteNumero";
            lblDigiteNumero.Size = new Size(110, 15);
            lblDigiteNumero.TabIndex = 1;
            lblDigiteNumero.Text = "Digite um número: ";
            // 
            // btnCalcula
            // 
            btnCalcula.Location = new Point(154, 107);
            btnCalcula.Name = "btnCalcula";
            btnCalcula.Size = new Size(102, 45);
            btnCalcula.TabIndex = 2;
            btnCalcula.Text = "Calcular H";
            btnCalcula.UseVisualStyleBackColor = true;
            btnCalcula.Click += btnCalcula_Click;
            // 
            // lblNumeroH
            // 
            lblNumeroH.AutoSize = true;
            lblNumeroH.Location = new Point(14, 193);
            lblNumeroH.Name = "lblNumeroH";
            lblNumeroH.Size = new Size(134, 15);
            lblNumeroH.TabIndex = 3;
            lblNumeroH.Text = "O valor do número H é: ";
            // 
            // txtH
            // 
            txtH.Enabled = false;
            txtH.Location = new Point(154, 193);
            txtH.Name = "txtH";
            txtH.Size = new Size(141, 23);
            txtH.TabIndex = 4;
            // 
            // frmExercicio2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(690, 308);
            Controls.Add(txtH);
            Controls.Add(lblNumeroH);
            Controls.Add(btnCalcula);
            Controls.Add(lblDigiteNumero);
            Controls.Add(txtN);
            Name = "frmExercicio2";
            Text = "frmExercicio2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtN;
        private Label lblDigiteNumero;
        private Button btnCalcula;
        private Label lblNumeroH;
        private TextBox txtH;
    }
}
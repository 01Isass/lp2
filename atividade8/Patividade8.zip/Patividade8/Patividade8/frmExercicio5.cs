﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Patividade8
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnRespostas_Click(object sender, EventArgs e)
        {
            int ultimoDigitoRA = 7;  //Número de alunos com base no último digito do RA 
            if (ultimoDigitoRA == 0) //Se for 0 ele coloca no minimo 2 alunos
            {
                ultimoDigitoRA = 2;
            }

            char[] respostas = { 'A', 'B', 'A', 'C', 'A', 'D', 'E', 'E', 'B', 'A' };

            char[,] respostaAlunos = new char[ultimoDigitoRA, 10];

            lstbxRespostas.Items.Clear();

            for (int aluno=0; aluno<ultimoDigitoRA; aluno++)
            {
                for(int questoes=0; questoes<10; questoes++)
                {
                    string auxiliar;
                    auxiliar = Interaction.InputBox($"Digite a resposta do aluno {aluno + 1} na questão {questoes + 1}: ", "Entrada de dados").ToUpper();

                    //string opcoesValidas = "ABCDE";
                    //if (auxiliar.Length ==1 && auxiliar[0] =='A' || auxiliar[0] =='B' || auxiliar[0]=='C' || auxiliar[0]=='D' || auxiliar[0]=='E')
                    //OU if (auxiliar.Length ==1 && opcoesValidas.Contains(auxiliar)) USANDO a string opcoesValidas
                    //OU colocar direto no if sem usar a variavel funcoesValidas
                    if (auxiliar.Length ==1 && "ABCDE".Contains(auxiliar))
                    {
                        char resposta = auxiliar[0];
                        respostaAlunos[aluno, questoes] = resposta;

                        if (respostaAlunos[aluno, questoes] == respostas[questoes])
                        {
                            lstbxRespostas.Items.Add($"O aluno {aluno + 1} acertou a questão {questoes + 1}. Era {respostas[questoes]}, e ele/ela colocou {respostaAlunos[aluno,questoes]}");
                        } else
                        {
                            lstbxRespostas.Items.Add($"O aluno {aluno + 1} errou a questão {questoes + 1}. Era {respostas[questoes]}, e ele/ela colocou {respostaAlunos[aluno, questoes]}");
                        }


                    } else
                    {
                        MessageBox.Show("Deve ser apenas 1 caracter, contendo uma das seguintes letras: ''A B C D E''");
                        questoes--;
                    }
                }
            }


        }
    }
}

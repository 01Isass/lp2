﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pvendas02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }



        private void btnVerifica_Click(object sender, EventArgs e)
        {
            Double[,] diasMes = new Double[2, 4];
            String auxiliar = "";

            lstbx.Items.Clear();
            double totalMes = 0;
            double totalMeses = 0;

            for (int linha = 0; linha < 2; linha++)
            {
                totalMeses += totalMes;
                totalMes = 0;
                for (int colunas = 0; colunas <4;  colunas++)
                {

                    auxiliar = Interaction.InputBox($"Digite o total vendido no mês {linha+1} na semana {colunas + 1}: ", "Entrada de dados");
                    if (!double.TryParse(auxiliar, out diasMes[linha, colunas]) || diasMes[linha,colunas] < 0)
                    {
                        MessageBox.Show($"Coloque aqui somente o valor do que foi vendido na semana {colunas+1} do mês {linha+1}. Esse valor precisa ser maior que zero(0)");
                        colunas--;
                       
                    } else
                    {
                        lstbx.Items.Add($"Total do mês: {linha + 1}   Semana: {colunas + 1}   R${diasMes[linha, colunas]}").ToString("N2");
                        //txtVolume.Text = volume.ToString("N2");

                        totalMes += diasMes[linha, colunas];
                        //totalMeses += totalMes;

                    }


                }
                    lstbx.Items.Add($">>Total Mês:   {totalMes}");
                    lstbx.Items.Add("-------------------");
                //lstbx.Items.Add($">>Total Geral   {totalMeses}");



            }
            totalMeses += totalMes;
            lstbx.Items.Add($">>Total Geral   {totalMeses}");

        }

        private void btnLimpa_Click(object sender, EventArgs e)
        {
            lstbx.Items.Clear();
        }
    }
}

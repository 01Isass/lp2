using System.Diagnostics.Eventing.Reader;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double valor1, valor2, valor3;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValor1.Clear();
            txtValor2.Clear();
            txtValor3.Clear();
        }

        private void txtValor1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtValor1.Text, out valor1) || (valor1 == 0))
            {
                MessageBox.Show("Digite um N�MERO diferente de 0!");
                txtValor1.Focus();
            }
        }

        private void txtValor2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtValor2.Text, out valor2) || (valor2 == 0))
            {
                MessageBox.Show("Digite um N�MERO diferente de 0!");
                txtValor2.Focus();
            }
        }

        private void txtValor3_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtValor3.Text, out valor3) || (valor3 ==0))
            {
                MessageBox.Show("Digite um N�MERO diferente de 0!");
                txtValor3.Focus();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if ((valor2 + valor3) > valor1 && (valor1 + valor3) >  valor2 && (valor1 + valor2) > valor3)
            {
                MessageBox.Show("Pode formar um tri�ngulo");

                if (valor1 == valor2 && valor2 == valor3)
                {
                    MessageBox.Show("O tri�ngulo ser� equil�tero");
                }
                else if (valor1 != valor2 && valor2 != valor3 && valor1 != valor3)
                {
                    MessageBox.Show("Seu tri�ngulo ser� escaleno");
                }
                else
                {
                    MessageBox.Show("Seu tri�ngulo ser� is�sceles");
                }
            } 
            else
            {
                MessageBox.Show("N�o pode formar um tri�ngulo");
            }

        }
    }
}

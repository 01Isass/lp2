﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        int numeroN;
        double numeroH = 0;
        private void btnCalcula_Click(object sender, EventArgs e)
        {
            if (txtN.Text == "") 
            {
                MessageBox.Show("Digite um número acima de zero");
                txtN.Focus();
            } 
            else if (!int.TryParse(txtN.Text, out numeroN) || numeroN <=0) 
            {
                MessageBox.Show("Você não digitou um número válido");
                txtN.Focus();
            }

            for (int i = 1; i <= numeroN; i++)
            {
                numeroH += (double) 1 / i;
            }

            txtH.Text = numeroH.ToString();

        }
    }
}

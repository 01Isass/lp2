﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        string fraseOriginal;
        string frase;
        string fraseInvertida;
        private void txtFrase_Validating(object sender, CancelEventArgs e)
        {
            fraseOriginal = txtFrase.Text;
            frase = txtFrase.Text;
            int quantidadeLetras = frase.Count(char.IsLetter);

            if (quantidadeLetras > 50)
            {
                MessageBox.Show("A frase deve ter no máximo 50 letras");
                txtFrase.Focus();
            }
        }

        private void btnPalíndromo_Click(object sender, EventArgs e)
        {
            frase = txtFrase.Text.ToUpper(); //colocando na variável frase e colocando tudo em maius
            frase = frase.Replace(" ", "");  //Essa função tira os espaços da frase

            char[] arrChar = frase.ToCharArray();  //Transforma frase em um array
            Array.Reverse(arrChar);                //Usa o Reverse, que só da pra usar em array
            fraseInvertida  = new string(arrChar); //Transforma o array em String coloca na variavel fraseInvertida

            if (frase == fraseInvertida)
            {
                MessageBox.Show($"A frase que você digitou: ''{fraseOriginal}'' é palíndromo, veja ela ao contrário: ''{fraseInvertida}''");
            } else
            {
                MessageBox.Show($"A frase que você digitou: ''{fraseOriginal}'' não é palíndromo");
            }


            

        }
    }
}

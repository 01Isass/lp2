﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            int numero1;
            int numero2;
            if (!int.TryParse(txtNumero1.Text, out numero1) || !int.TryParse(txtNumero2.Text, out numero2)
                || (numero2 <= numero1))
            {
                MessageBox.Show("Números inválidos! Lembre-se que o segundo número precisa ser maior que o primeiro");
                txtNumero2.Focus();
            } else
            {
                Random objetoR = new Random();
                int aleatorio = objetoR.Next(numero1, numero2);
                MessageBox.Show("Número aleatório: " + aleatorio);
            }
        }
    }
}

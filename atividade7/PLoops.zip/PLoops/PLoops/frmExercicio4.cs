﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        int producao = 0;
        double salario = 0.0;
        double gratificacao = 0.0;
        double salarioBruto = 0.0;
        double A = 0.0;
        int B = 0;
        int C = 0;
        int D = 0;
        private void txtProducao_Validating(object sender, CancelEventArgs e)
        {
            if (!int.TryParse(txtProducao.Text, out producao) || producao < 0)
            {
                e.Cancel = true;
                MessageBox.Show("Digite um número inteiro que não seja negativo");
                txtProducao.Focus();
            } else
            {
                B = C = D = 0;
                if (producao >= 100)
                {
                    B = 1;
                }

               if(producao >= 120)
                {
                    B = 1;
                    C = 1;
                }
               
               if(producao >= 150)
                {
                    B = 1;
                    C = 1;
                    D = 1;
                }
            }
        }

        private void txtSalario_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtSalario.Text, out salario) || salario <= 0)
            {
                e.Cancel = true;
                MessageBox.Show("Digite um número maior que zero");
                txtSalario.Focus();
            } else
            {
                A = salario;
            }
        }

        private void txtGratificacao_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtGratificacao.Text, out gratificacao) || gratificacao < 0)
            {
                e.Cancel = true;
                MessageBox.Show("O número não pode ser menor que zero");
                txtGratificacao.Focus();
            }
        }

        private void btnCalculaSalarioBruto_Click(object sender, EventArgs e)
        {
            salarioBruto = salario + (salario * (0.05 * B + 0.1 * C + 0.1 * D)) + gratificacao;

            if(salarioBruto > 7000  && !(producao>=150 && gratificacao > 0))
            {
                salarioBruto = 7000;
            }

            txtSalarioBruto.Text = salarioBruto.ToString("C2");
        }
    }
}

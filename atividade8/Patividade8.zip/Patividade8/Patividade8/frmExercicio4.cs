﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Patividade8
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecuta_Click(object sender, EventArgs e)
        {
            string auxiliar = "";
            string[] nome = new string[10];
            int[] tamanho = new int[10];

            for(int i=0; i < 10; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o nome da {i + 1} pessoa: ", "Entrada de dados");

                if (auxiliar=="" || auxiliar==" ")
                {
                    MessageBox.Show("O nome da pessoa não pode estar vazio ou ser apenas espaços");
                    i--;
                } else
                {
                    nome[i] = auxiliar;
                    tamanho[i] = auxiliar.Replace(" ", "").Length;
                    lstbxNomes.Items.Add($"O nome: {nome[i]} tem {tamanho[i]} caracteres");
                }

            }
        }
    }
}

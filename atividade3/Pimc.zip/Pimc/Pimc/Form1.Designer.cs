﻿namespace Pimc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblPeso = new Label();
            lblAltura = new Label();
            lblIMC = new Label();
            btnCalcular = new Button();
            btnLimpar = new Button();
            btnSair = new Button();
            txtIMC = new TextBox();
            mskPesoAtual = new MaskedTextBox();
            mskdAltura = new MaskedTextBox();
            SuspendLayout();
            // 
            // lblPeso
            // 
            lblPeso.AutoSize = true;
            lblPeso.Location = new Point(56, 50);
            lblPeso.Name = "lblPeso";
            lblPeso.Size = new Size(92, 25);
            lblPeso.TabIndex = 0;
            lblPeso.Text = "Peso atual";
            // 
            // lblAltura
            // 
            lblAltura.AutoSize = true;
            lblAltura.Location = new Point(56, 97);
            lblAltura.Name = "lblAltura";
            lblAltura.Size = new Size(59, 25);
            lblAltura.TabIndex = 1;
            lblAltura.Text = "Altura";
            // 
            // lblIMC
            // 
            lblIMC.AutoSize = true;
            lblIMC.Location = new Point(56, 151);
            lblIMC.Name = "lblIMC";
            lblIMC.Size = new Size(44, 25);
            lblIMC.TabIndex = 2;
            lblIMC.Text = "IMC";
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(108, 225);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(112, 34);
            btnCalcular.TabIndex = 3;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(282, 225);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(112, 34);
            btnLimpar.TabIndex = 4;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(449, 225);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(112, 34);
            btnSair.TabIndex = 5;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // txtIMC
            // 
            txtIMC.Enabled = false;
            txtIMC.Location = new Point(175, 151);
            txtIMC.Name = "txtIMC";
            txtIMC.Size = new Size(386, 31);
            txtIMC.TabIndex = 8;
            // 
            // mskPesoAtual
            // 
            mskPesoAtual.Location = new Point(210, 50);
            mskPesoAtual.Mask = "000.00";
            mskPesoAtual.Name = "mskPesoAtual";
            mskPesoAtual.Size = new Size(150, 31);
            mskPesoAtual.TabIndex = 9;
            mskPesoAtual.Validated += mskPesoAtual_Validated;
            // 
            // mskdAltura
            // 
            mskdAltura.Location = new Point(210, 97);
            mskdAltura.Mask = "0.00";
            mskdAltura.Name = "mskdAltura";
            mskdAltura.Size = new Size(150, 31);
            mskdAltura.TabIndex = 10;
            mskdAltura.Validated += mskdAltura_Validated;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(mskdAltura);
            Controls.Add(mskPesoAtual);
            Controls.Add(txtIMC);
            Controls.Add(btnSair);
            Controls.Add(btnLimpar);
            Controls.Add(btnCalcular);
            Controls.Add(lblIMC);
            Controls.Add(lblAltura);
            Controls.Add(lblPeso);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblPeso;
        private Label lblAltura;
        private Label lblIMC;
        private Button btnCalcular;
        private Button btnLimpar;
        private Button btnSair;
        private TextBox txtIMC;
        private MaskedTextBox mskPesoAtual;
        private MaskedTextBox mskdAltura;
    }
}

﻿namespace Pclasses
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnInstanciarHorista = new Button();
            txtHora = new TextBox();
            txtSalario = new TextBox();
            txtNome = new TextBox();
            txtMatricula = new TextBox();
            lblDataEntradanaEmpresa = new Label();
            lblSalárioHora = new Label();
            lblNome = new Label();
            lblMatrícula = new Label();
            lblHora = new Label();
            lblDiasFalta = new Label();
            txtData = new TextBox();
            txtFalta = new TextBox();
            SuspendLayout();
            // 
            // btnInstanciarHorista
            // 
            btnInstanciarHorista.Location = new Point(211, 410);
            btnInstanciarHorista.Name = "btnInstanciarHorista";
            btnInstanciarHorista.Size = new Size(215, 73);
            btnInstanciarHorista.TabIndex = 20;
            btnInstanciarHorista.Text = "Instanciar Horista";
            btnInstanciarHorista.UseVisualStyleBackColor = true;
            btnInstanciarHorista.Click += btnInstanciarHorista_Click;
            // 
            // txtHora
            // 
            txtHora.Location = new Point(221, 197);
            txtHora.Name = "txtHora";
            txtHora.Size = new Size(150, 31);
            txtHora.TabIndex = 17;
            // 
            // txtSalario
            // 
            txtSalario.Location = new Point(221, 132);
            txtSalario.Name = "txtSalario";
            txtSalario.Size = new Size(150, 31);
            txtSalario.TabIndex = 16;
            // 
            // txtNome
            // 
            txtNome.Location = new Point(221, 68);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(150, 31);
            txtNome.TabIndex = 15;
            // 
            // txtMatricula
            // 
            txtMatricula.Location = new Point(221, 12);
            txtMatricula.Name = "txtMatricula";
            txtMatricula.Size = new Size(150, 31);
            txtMatricula.TabIndex = 14;
            // 
            // lblDataEntradanaEmpresa
            // 
            lblDataEntradanaEmpresa.AutoSize = true;
            lblDataEntradanaEmpresa.Location = new Point(36, 245);
            lblDataEntradanaEmpresa.Name = "lblDataEntradanaEmpresa";
            lblDataEntradanaEmpresa.Size = new Size(240, 25);
            lblDataEntradanaEmpresa.TabIndex = 13;
            lblDataEntradanaEmpresa.Text = "Data da entrada na empresa:";
            // 
            // lblSalárioHora
            // 
            lblSalárioHora.AutoSize = true;
            lblSalárioHora.Location = new Point(36, 132);
            lblSalárioHora.Name = "lblSalárioHora";
            lblSalárioHora.Size = new Size(142, 25);
            lblSalárioHora.TabIndex = 12;
            lblSalárioHora.Text = "Salário por Hora";
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Location = new Point(36, 74);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(61, 25);
            lblNome.TabIndex = 11;
            lblNome.Text = "Nome";
            // 
            // lblMatrícula
            // 
            lblMatrícula.AutoSize = true;
            lblMatrícula.Location = new Point(36, 18);
            lblMatrícula.Name = "lblMatrícula";
            lblMatrícula.Size = new Size(84, 25);
            lblMatrícula.TabIndex = 10;
            lblMatrícula.Text = "Matrícula";
            // 
            // lblHora
            // 
            lblHora.AutoSize = true;
            lblHora.Location = new Point(36, 197);
            lblHora.Name = "lblHora";
            lblHora.Size = new Size(154, 25);
            lblHora.TabIndex = 20;
            lblHora.Text = "Número de Horas";
            // 
            // lblDiasFalta
            // 
            lblDiasFalta.AutoSize = true;
            lblDiasFalta.Location = new Point(36, 310);
            lblDiasFalta.Name = "lblDiasFalta";
            lblDiasFalta.Size = new Size(112, 25);
            lblDiasFalta.TabIndex = 21;
            lblDiasFalta.Text = "Dias de Falta";
            // 
            // txtData
            // 
            txtData.Location = new Point(315, 245);
            txtData.Name = "txtData";
            txtData.Size = new Size(150, 31);
            txtData.TabIndex = 18;
            // 
            // txtFalta
            // 
            txtFalta.Location = new Point(211, 310);
            txtFalta.Name = "txtFalta";
            txtFalta.Size = new Size(150, 31);
            txtFalta.TabIndex = 19;
            // 
            // frmHorista
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(734, 560);
            Controls.Add(txtFalta);
            Controls.Add(txtData);
            Controls.Add(lblDiasFalta);
            Controls.Add(lblHora);
            Controls.Add(btnInstanciarHorista);
            Controls.Add(txtHora);
            Controls.Add(txtSalario);
            Controls.Add(txtNome);
            Controls.Add(txtMatricula);
            Controls.Add(lblDataEntradanaEmpresa);
            Controls.Add(lblSalárioHora);
            Controls.Add(lblNome);
            Controls.Add(lblMatrícula);
            Name = "frmHorista";
            Text = "frmHorista";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button btnInstanciarHorista;
        private TextBox txtHora;
        private TextBox txtSalario;
        private TextBox txtNome;
        private TextBox txtMatricula;
        private Label lblDataEntradanaEmpresa;
        private Label lblSalárioHora;
        private Label lblNome;
        private Label lblMatrícula;
        private Label lblHora;
        private Label lblDiasFalta;
        private TextBox txtData;
        private TextBox txtFalta;
    }
}
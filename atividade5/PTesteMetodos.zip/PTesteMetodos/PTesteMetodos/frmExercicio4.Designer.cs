﻿namespace PTesteMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnQntdCaracter = new System.Windows.Forms.Button();
            this.btnPrimeiroCaracterBranco = new System.Windows.Forms.Button();
            this.btnQntdCaracteresAlfabeticos = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(57, 53);
            this.rchtxtFrase.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(193, 152);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "";
            // 
            // btnQntdCaracter
            // 
            this.btnQntdCaracter.Location = new System.Drawing.Point(299, 32);
            this.btnQntdCaracter.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnQntdCaracter.Name = "btnQntdCaracter";
            this.btnQntdCaracter.Size = new System.Drawing.Size(80, 50);
            this.btnQntdCaracter.TabIndex = 1;
            this.btnQntdCaracter.Text = "Quantos caracteres númericos";
            this.btnQntdCaracter.UseVisualStyleBackColor = true;
            this.btnQntdCaracter.Click += new System.EventHandler(this.btnQntdCaracter_Click);
            // 
            // btnPrimeiroCaracterBranco
            // 
            this.btnPrimeiroCaracterBranco.Location = new System.Drawing.Point(299, 105);
            this.btnPrimeiroCaracterBranco.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnPrimeiroCaracterBranco.Name = "btnPrimeiroCaracterBranco";
            this.btnPrimeiroCaracterBranco.Size = new System.Drawing.Size(80, 54);
            this.btnPrimeiroCaracterBranco.TabIndex = 2;
            this.btnPrimeiroCaracterBranco.Text = "Primeiro caracter branco";
            this.btnPrimeiroCaracterBranco.UseVisualStyleBackColor = true;
            this.btnPrimeiroCaracterBranco.Click += new System.EventHandler(this.btnPrimeiroCaracterBranco_Click);
            // 
            // btnQntdCaracteresAlfabeticos
            // 
            this.btnQntdCaracteresAlfabeticos.Location = new System.Drawing.Point(299, 172);
            this.btnQntdCaracteresAlfabeticos.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnQntdCaracteresAlfabeticos.Name = "btnQntdCaracteresAlfabeticos";
            this.btnQntdCaracteresAlfabeticos.Size = new System.Drawing.Size(80, 51);
            this.btnQntdCaracteresAlfabeticos.TabIndex = 3;
            this.btnQntdCaracteresAlfabeticos.Text = "Quantidade de caracteres alfabéticos";
            this.btnQntdCaracteresAlfabeticos.UseVisualStyleBackColor = true;
            this.btnQntdCaracteresAlfabeticos.Click += new System.EventHandler(this.btnQntdCaracteresAlfabeticos_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(533, 292);
            this.Controls.Add(this.btnQntdCaracteresAlfabeticos);
            this.Controls.Add(this.btnPrimeiroCaracterBranco);
            this.Controls.Add(this.btnQntdCaracter);
            this.Controls.Add(this.rchtxtFrase);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnQntdCaracter;
        private System.Windows.Forms.Button btnPrimeiroCaracterBranco;
        private System.Windows.Forms.Button btnQntdCaracteresAlfabeticos;
    }
}
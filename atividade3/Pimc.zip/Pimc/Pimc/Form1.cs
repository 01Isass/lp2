namespace Pimc
{
    public partial class Form1 : Form
    {
        double imc, peso, altura;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskdAltura.Clear();
            mskPesoAtual.Clear();
            txtIMC.Clear();
        }

    

    
        

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            imc = peso / Math.Pow(altura, 2);
            imc = Math.Round(imc, 1);
            txtIMC.Text = imc.ToString();

            if (imc < 18.5)
            {
                MessageBox.Show("Resultado: Magreza");
            }
            else if (imc <= 24.9)
            {
                MessageBox.Show("Resultado: Peso normal");
            }
            else if (imc <= 29.9)
            {
                MessageBox.Show("Resultado: Excesso de peso");
            }
            else if (imc <= 34.9)
            {
                MessageBox.Show("Resultado: Obesidade");
            }
            else
            {
                MessageBox.Show("Resultado: Obesidade EXTREMA");
            }
        }

        private void mskPesoAtual_Validated(object sender, EventArgs e)
        {
            try
            {
                peso = Convert.ToDouble(mskPesoAtual.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Peso inv�lido");
                mskPesoAtual.Focus();
            }
        }

        private void mskdAltura_Validated(object sender, EventArgs e)
        {
            try
            {
                altura = Convert.ToDouble(mskdAltura.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Altura inv�lida");
                mskdAltura.Focus();
            }
        }
    }
}

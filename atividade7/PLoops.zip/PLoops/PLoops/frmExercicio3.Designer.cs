﻿namespace PLoops
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtFrase = new TextBox();
            lblFrase = new Label();
            btnPalíndromo = new Button();
            SuspendLayout();
            // 
            // txtFrase
            // 
            txtFrase.Location = new Point(158, 54);
            txtFrase.Name = "txtFrase";
            txtFrase.Size = new Size(528, 23);
            txtFrase.TabIndex = 0;
            txtFrase.Validating += txtFrase_Validating;
            // 
            // lblFrase
            // 
            lblFrase.AutoSize = true;
            lblFrase.Location = new Point(48, 57);
            lblFrase.Name = "lblFrase";
            lblFrase.Size = new Size(93, 15);
            lblFrase.TabIndex = 1;
            lblFrase.Text = "Digite uma frase";
            // 
            // btnPalíndromo
            // 
            btnPalíndromo.Location = new Point(178, 134);
            btnPalíndromo.Name = "btnPalíndromo";
            btnPalíndromo.Size = new Size(138, 48);
            btnPalíndromo.TabIndex = 2;
            btnPalíndromo.Text = "É palíndromo?";
            btnPalíndromo.UseVisualStyleBackColor = true;
            btnPalíndromo.Click += btnPalíndromo_Click;
            // 
            // frmExercicio3
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(747, 245);
            Controls.Add(btnPalíndromo);
            Controls.Add(lblFrase);
            Controls.Add(txtFrase);
            Name = "frmExercicio3";
            Text = "frmExercicio3";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtFrase;
        private Label lblFrase;
        private Button btnPalíndromo;
    }
}
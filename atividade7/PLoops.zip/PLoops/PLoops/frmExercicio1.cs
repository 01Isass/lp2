﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnEspacoBranco_Click(object sender, EventArgs e)
        {
            int numeroEspaco = 0;
            int tamanhoFrase = rchtxtTexto.Text.Length;

            if (rchtxtTexto.Text == "")
                MessageBox.Show("Digite uma frase!");

            for (int i = 0; i < tamanhoFrase; i++)
            {
                if (Char.IsWhiteSpace(rchtxtTexto.Text[i]))
                {
                    numeroEspaco++;
                }
            }
            MessageBox.Show("O numero de espaços em branco é: " + numeroEspaco);
        }

        private void btnVezesR_Click(object sender, EventArgs e)
        {
            int qtdeR = 0;
            foreach (char c in rchtxtTexto.Text.ToUpper())
            {
                if (c == 'R')
                qtdeR++;
            }
            MessageBox.Show("O numero de letras 'R' é: " + qtdeR);
        }

        private void btnParLetras_Click(object sender, EventArgs e)
        {
            int pares = 0;
            int i = 0;

            while ( i < rchtxtTexto.Text.Length - 1)
            {
                if (rchtxtTexto.Text[i] == rchtxtTexto.Text[i + 1])
                {
                    pares++;
                }
                i++;
            }
            MessageBox.Show("O numero de vezes que ocorre mesmo par de letras é " + pares);
        }
    }
}

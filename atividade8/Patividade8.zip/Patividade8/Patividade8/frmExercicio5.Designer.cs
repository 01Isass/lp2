﻿namespace Patividade8
{
    partial class frmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstbxRespostas = new System.Windows.Forms.ListBox();
            this.btnRespostas = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lstbxRespostas
            // 
            this.lstbxRespostas.FormattingEnabled = true;
            this.lstbxRespostas.Location = new System.Drawing.Point(429, 77);
            this.lstbxRespostas.Name = "lstbxRespostas";
            this.lstbxRespostas.Size = new System.Drawing.Size(302, 277);
            this.lstbxRespostas.TabIndex = 0;
            // 
            // btnRespostas
            // 
            this.btnRespostas.Location = new System.Drawing.Point(128, 77);
            this.btnRespostas.Name = "btnRespostas";
            this.btnRespostas.Size = new System.Drawing.Size(134, 84);
            this.btnRespostas.TabIndex = 1;
            this.btnRespostas.Text = "Adicionar Respostas";
            this.btnRespostas.UseVisualStyleBackColor = true;
            this.btnRespostas.Click += new System.EventHandler(this.btnRespostas_Click);
            // 
            // frmExercicio5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnRespostas);
            this.Controls.Add(this.lstbxRespostas);
            this.Name = "frmExercicio5";
            this.Text = "frmExercicio5";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lstbxRespostas;
        private System.Windows.Forms.Button btnRespostas;
    }
}
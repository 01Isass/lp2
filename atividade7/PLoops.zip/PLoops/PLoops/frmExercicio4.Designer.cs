﻿namespace PLoops
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtNome = new TextBox();
            lblNome = new Label();
            lblMatricula = new Label();
            lblProducao = new Label();
            lblSalario = new Label();
            lblGratificacao = new Label();
            lblSalarioBruto = new Label();
            txtMatricula = new TextBox();
            txtProducao = new TextBox();
            txtSalario = new TextBox();
            txtGratificacao = new TextBox();
            txtSalarioBruto = new TextBox();
            btnCalculaSalarioBruto = new Button();
            SuspendLayout();
            // 
            // txtNome
            // 
            txtNome.Location = new Point(172, 58);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(143, 23);
            txtNome.TabIndex = 0;
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Location = new Point(50, 64);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(40, 15);
            lblNome.TabIndex = 1;
            lblNome.Text = "Nome";
            // 
            // lblMatricula
            // 
            lblMatricula.AutoSize = true;
            lblMatricula.Location = new Point(50, 101);
            lblMatricula.Name = "lblMatricula";
            lblMatricula.Size = new Size(57, 15);
            lblMatricula.TabIndex = 2;
            lblMatricula.Text = "Matrícula";
            // 
            // lblProducao
            // 
            lblProducao.AutoSize = true;
            lblProducao.Location = new Point(50, 138);
            lblProducao.Name = "lblProducao";
            lblProducao.Size = new Size(58, 15);
            lblProducao.TabIndex = 3;
            lblProducao.Text = "Produção";
            // 
            // lblSalario
            // 
            lblSalario.AutoSize = true;
            lblSalario.Location = new Point(50, 183);
            lblSalario.Name = "lblSalario";
            lblSalario.Size = new Size(42, 15);
            lblSalario.TabIndex = 4;
            lblSalario.Text = "Salário";
            // 
            // lblGratificacao
            // 
            lblGratificacao.AutoSize = true;
            lblGratificacao.Location = new Point(50, 228);
            lblGratificacao.Name = "lblGratificacao";
            lblGratificacao.Size = new Size(70, 15);
            lblGratificacao.TabIndex = 5;
            lblGratificacao.Text = "Gratificação";
            // 
            // lblSalarioBruto
            // 
            lblSalarioBruto.AutoSize = true;
            lblSalarioBruto.Location = new Point(50, 320);
            lblSalarioBruto.Name = "lblSalarioBruto";
            lblSalarioBruto.Size = new Size(74, 15);
            lblSalarioBruto.TabIndex = 6;
            lblSalarioBruto.Text = "Salário Bruto";
            // 
            // txtMatricula
            // 
            txtMatricula.Location = new Point(172, 101);
            txtMatricula.Name = "txtMatricula";
            txtMatricula.Size = new Size(143, 23);
            txtMatricula.TabIndex = 7;
            // 
            // txtProducao
            // 
            txtProducao.Location = new Point(172, 138);
            txtProducao.Name = "txtProducao";
            txtProducao.Size = new Size(143, 23);
            txtProducao.TabIndex = 8;
            txtProducao.Validating += txtProducao_Validating;
            // 
            // txtSalario
            // 
            txtSalario.Location = new Point(172, 180);
            txtSalario.Name = "txtSalario";
            txtSalario.Size = new Size(143, 23);
            txtSalario.TabIndex = 9;
            txtSalario.Validating += txtSalario_Validating;
            // 
            // txtGratificacao
            // 
            txtGratificacao.Location = new Point(172, 225);
            txtGratificacao.Name = "txtGratificacao";
            txtGratificacao.Size = new Size(143, 23);
            txtGratificacao.TabIndex = 10;
            txtGratificacao.Validating += txtGratificacao_Validating;
            // 
            // txtSalarioBruto
            // 
            txtSalarioBruto.Enabled = false;
            txtSalarioBruto.Location = new Point(172, 317);
            txtSalarioBruto.Name = "txtSalarioBruto";
            txtSalarioBruto.Size = new Size(143, 23);
            txtSalarioBruto.TabIndex = 11;
            // 
            // btnCalculaSalarioBruto
            // 
            btnCalculaSalarioBruto.Location = new Point(409, 206);
            btnCalculaSalarioBruto.Name = "btnCalculaSalarioBruto";
            btnCalculaSalarioBruto.Size = new Size(172, 59);
            btnCalculaSalarioBruto.TabIndex = 12;
            btnCalculaSalarioBruto.Text = "Calcular Salário Bruto";
            btnCalculaSalarioBruto.UseVisualStyleBackColor = true;
            btnCalculaSalarioBruto.Click += btnCalculaSalarioBruto_Click;
            // 
            // frmExercicio4
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnCalculaSalarioBruto);
            Controls.Add(txtSalarioBruto);
            Controls.Add(txtGratificacao);
            Controls.Add(txtSalario);
            Controls.Add(txtProducao);
            Controls.Add(txtMatricula);
            Controls.Add(lblSalarioBruto);
            Controls.Add(lblGratificacao);
            Controls.Add(lblSalario);
            Controls.Add(lblProducao);
            Controls.Add(lblMatricula);
            Controls.Add(lblNome);
            Controls.Add(txtNome);
            Name = "frmExercicio4";
            Text = "frmExercicio4";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtNome;
        private Label lblNome;
        private Label lblMatricula;
        private Label lblProducao;
        private Label lblSalario;
        private Label lblGratificacao;
        private Label lblSalarioBruto;
        private TextBox txtMatricula;
        private TextBox txtProducao;
        private TextBox txtSalario;
        private TextBox txtGratificacao;
        private TextBox txtSalarioBruto;
        private Button btnCalculaSalarioBruto;
    }
}
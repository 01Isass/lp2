﻿namespace PTesteMetodos
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTexto1 = new System.Windows.Forms.Label();
            this.txtPalavra1 = new System.Windows.Forms.TextBox();
            this.txtPalavra2 = new System.Windows.Forms.TextBox();
            this.btnRemoverOcorrencias1no2 = new System.Windows.Forms.Button();
            this.btnContrario = new System.Windows.Forms.Button();
            this.lblTexto2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblTexto1
            // 
            this.lblTexto1.AutoSize = true;
            this.lblTexto1.Location = new System.Drawing.Point(54, 53);
            this.lblTexto1.Name = "lblTexto1";
            this.lblTexto1.Size = new System.Drawing.Size(61, 20);
            this.lblTexto1.TabIndex = 0;
            this.lblTexto1.Text = "Texto 1";
            // 
            // txtPalavra1
            // 
            this.txtPalavra1.Location = new System.Drawing.Point(220, 50);
            this.txtPalavra1.Name = "txtPalavra1";
            this.txtPalavra1.Size = new System.Drawing.Size(197, 26);
            this.txtPalavra1.TabIndex = 1;
            // 
            // txtPalavra2
            // 
            this.txtPalavra2.Location = new System.Drawing.Point(220, 112);
            this.txtPalavra2.Name = "txtPalavra2";
            this.txtPalavra2.Size = new System.Drawing.Size(197, 26);
            this.txtPalavra2.TabIndex = 2;
            // 
            // btnRemoverOcorrencias1no2
            // 
            this.btnRemoverOcorrencias1no2.Location = new System.Drawing.Point(142, 192);
            this.btnRemoverOcorrencias1no2.Name = "btnRemoverOcorrencias1no2";
            this.btnRemoverOcorrencias1no2.Size = new System.Drawing.Size(196, 105);
            this.btnRemoverOcorrencias1no2.TabIndex = 3;
            this.btnRemoverOcorrencias1no2.Text = "Remover ocorrências do texto 1 no texto 2";
            this.btnRemoverOcorrencias1no2.UseVisualStyleBackColor = true;
            this.btnRemoverOcorrencias1no2.Click += new System.EventHandler(this.btnRemoverOcorrencias1no2_Click);
            // 
            // btnContrario
            // 
            this.btnContrario.Location = new System.Drawing.Point(397, 192);
            this.btnContrario.Name = "btnContrario";
            this.btnContrario.Size = new System.Drawing.Size(196, 105);
            this.btnContrario.TabIndex = 4;
            this.btnContrario.Text = "Retornar texto 1 ao contrário";
            this.btnContrario.UseVisualStyleBackColor = true;
            this.btnContrario.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblTexto2
            // 
            this.lblTexto2.AutoSize = true;
            this.lblTexto2.Location = new System.Drawing.Point(54, 115);
            this.lblTexto2.Name = "lblTexto2";
            this.lblTexto2.Size = new System.Drawing.Size(61, 20);
            this.lblTexto2.TabIndex = 5;
            this.lblTexto2.Text = "Texto 2";
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblTexto2);
            this.Controls.Add(this.btnContrario);
            this.Controls.Add(this.btnRemoverOcorrencias1no2);
            this.Controls.Add(this.txtPalavra2);
            this.Controls.Add(this.txtPalavra1);
            this.Controls.Add(this.lblTexto1);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTexto1;
        private System.Windows.Forms.TextBox txtPalavra1;
        private System.Windows.Forms.TextBox txtPalavra2;
        private System.Windows.Forms.Button btnRemoverOcorrencias1no2;
        private System.Windows.Forms.Button btnContrario;
        private System.Windows.Forms.Label lblTexto2;
    }
}